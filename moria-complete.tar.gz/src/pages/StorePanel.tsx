import { useState } from "react";
import { Sidebar } from "../components/admin/Sidebar";
import { AdminContent } from "../components/admin/AdminContent";
import "../styles/lojista.css";

export default function StorePanel() {
  const [activeTab, setActiveTab] = useState("dashboard");

  return (
    <div className="lojista-layout">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      
      <main className="lojista-content lojista-fade-in">
        <div className="lojista-header">
          <div>
            <h1 className="lojista-title">
              {getPageTitle(activeTab)}
            </h1>
            <p className="lojista-subtitle">
              {getPageDescription(activeTab)}
            </p>
          </div>
        </div>
        
        <AdminContent activeTab={activeTab} />
      </main>
    </div>
  );
}

function getPageTitle(tab: string): string {
  const titles: Record<string, string> = {
    dashboard: "Dashboard",
    orders: "Pedidos",
    customers: "Clientes", 
    products: "Produtos",
    promotions: "Promoções",
    reports: "Relatórios",
    settings: "Configurações"
  };
  return titles[tab] || "Dashboard";
}

function getPageDescription(tab: string): string {
  const descriptions: Record<string, string> = {
    dashboard: "Visão geral dos pedidos e métricas da loja",
    orders: "Gerencie todos os pedidos e orçamentos",
    customers: "Visualize os clientes cadastrados automaticamente",
    products: "Gerencie o catálogo e estoque de produtos", 
    promotions: "Configure ofertas especiais e campanhas",
    reports: "Relatórios de vendas e análises detalhadas",
    settings: "Configurações do sistema e preferências"
  };
  return descriptions[tab] || "Painel administrativo da Moria Peças e Serviços";
}
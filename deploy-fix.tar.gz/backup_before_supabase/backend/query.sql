SELECT COUNT(*) as total FROM products;
